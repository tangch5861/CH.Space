﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CH.Domain.Commands
{
    public abstract class CourseCommand : Command
    {
    }
}
